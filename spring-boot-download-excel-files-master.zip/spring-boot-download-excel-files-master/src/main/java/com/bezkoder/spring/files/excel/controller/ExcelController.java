package com.bezkoder.spring.files.excel.controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bezkoder.spring.files.excel.helper.ExcelHelper;
import com.bezkoder.spring.files.excel.model.RegistrationRequest;
import com.bezkoder.spring.files.excel.model.RegistrationResponse;
import com.bezkoder.spring.files.excel.service.ExcelService;

//@CrossOrigin("http://localhost:8081")
@Controller
@RequestMapping("/api/excel")
public class ExcelController {

//  @Autowired
//  ExcelService fileService;
//
//  @GetMapping("/download")
//  public ResponseEntity<Resource> getFile() {
//    String filename = "Urls.xlsx";
//    InputStreamResource file = new InputStreamResource(fileService.load());
//
//    return ResponseEntity.ok()
//        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
//        .contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
//  }
	
	

//	  @Autowired
//	  ExcelService fileService;
//
//	  @GetMapping("/download/all")
//	  public ResponseEntity<Resource> downloadAll() {
//	    String filename = "All_Urls.xlsx";
//	    InputStreamResource file = new InputStreamResource(fileService.loadAll());
//
//	    return ResponseEntity.ok()
//	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
//	        .contentType(MediaType.parseMediaType(ExcelHelper.TYPE))
//	        .body(file);
//	  }
//
//	  @GetMapping("/download/custom")
//	  public ResponseEntity<Resource> downloadCustom(/* Add parameters if necessary */) {
//	    String filename = "Custom_Urls.xlsx";
//	    InputStreamResource file = new InputStreamResource(fileService.loadByCustomQuery(/* Pass parameters if necessary */));
//
//	    return ResponseEntity.ok()
//	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
//	        .contentType(MediaType.parseMediaType(ExcelHelper.TYPE))
//	        .body(file);
//	  }
//	}
	

	  @Autowired
	  ExcelService fileService;

	  
	  @PostMapping("/registration")
	    public ResponseEntity<?> registerUser(@RequestBody RegistrationRequest registrationRequest) {
	        // Assuming RegistrationRequest is a POJO class containing username and password fields.
	        // Perform any necessary logic for user registration here.

	        // For demonstration purposes, let's assume 'registrationRequest' contains the username and password.
	        String username = registrationRequest.getUserName();
	        String password = registrationRequest.getPassword();

	        // Perform your business logic here to check user credentials and respond accordingly.
	        // In this example, we are just returning a simple response based on the input username and password.
	        if ("admin".equals(username) && "adminpassword".equals(password)) {
	            return ResponseEntity.ok(new RegistrationResponse("admin page matched"));
	        } else if ("user".equals(username) && "userpassword".equals(password)) {
	            return ResponseEntity.ok(new RegistrationResponse("user page matched"));
	        } else {
	            return ResponseEntity.ok(new RegistrationResponse("invalid credential"));
	        }
	    }
	  
	  
	  
	  
	  
	  
	  
	  
	  @GetMapping("/download/all")
	  public ResponseEntity<Resource> downloadAll() {
	    String filename = "All_Urls.xlsx";
	    InputStreamResource file = new InputStreamResource(fileService.loadAll());

	    return ResponseEntity.ok()
	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
	        .contentType(MediaType.parseMediaType(ExcelHelper.TYPE))
	        .body(file);
	  }

	  @GetMapping("/download/custom")
	  public ResponseEntity<Resource> downloadCustom(
	      @RequestParam("startDate") String startDate,
	      @RequestParam("endDate") String endDate) {
	    String filename = "Custom_Urls.xlsx";
	    InputStreamResource file = new InputStreamResource(fileService.loadByCustomQuery(startDate, endDate));

	    return ResponseEntity.ok()
	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
	        .contentType(MediaType.parseMediaType(ExcelHelper.TYPE))
	        .body(file);
	  }
	}
	


