package com.bezkoder.spring.files.excel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bezkoder.spring.files.excel.model.User;
import com.bezkoder.spring.files.excel.model.QueriesMapping;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
    List<User> findByRole(QueriesMapping role);
}