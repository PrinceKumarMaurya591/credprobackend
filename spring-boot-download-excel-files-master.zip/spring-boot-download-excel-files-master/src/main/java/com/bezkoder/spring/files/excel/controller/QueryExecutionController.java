package com.bezkoder.spring.files.excel.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bezkoder.spring.files.excel.exception.QueryNotAssignedException;
import com.bezkoder.spring.files.excel.model.QueriesMapping;
import com.bezkoder.spring.files.excel.service.QueriesMappingServiceImpl;
import com.bezkoder.spring.files.excel.service.UserRoleService;



//public class QueryExecutionController {
//
//}
@RestController
@RequestMapping("/api")
public class QueryExecutionController {
//    @Autowired
//    private UserRoleService userRoleService;
//
//    @GetMapping("/queries")
//    public ResponseEntity<Map<String, Set<String>>> getMappedQueriesForUser(@RequestParam("username") String username) {
//        // Assuming you have a method in the UserRoleService to get the allowed queries for a user
//        Set<String> allowedQueries = userRoleService.getAllowedQueriesForUser(username);
//
//        if (allowedQueries.isEmpty()) {
//            return ResponseEntity.notFound().build();
//        }
//
//        Map<String, Set<String>> response = new HashMap<>();
//        response.put("allowed_queries", allowedQueries);
//
//        return ResponseEntity.ok(response);
//    }
//
//    @PostMapping("/execute")
//    public ResponseEntity<?> executeQuery(@RequestParam("username") String username, @RequestParam("query") String query) {
//        // Assuming you have a method in the UserRoleService to check if the user is allowed to execute the query
//        boolean isAllowed = userRoleService.isQueryAllowedForUser(username, query);
//
//        if (!isAllowed) {
//            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("User is not allowed to execute this query.");
//        }
//
//        // Execute the query and return the result, you'll need to implement the query execution logic
//        // For demonstration purposes, we'll just return a simple message here
//        String result = "Query executed successfully!";
//
//        return ResponseEntity.ok(result);
//    }
	
	@Autowired
	private QueriesMappingServiceImpl queriesMappingServiceImpl;
	
	 @GetMapping("/users/{userId}/queries")
	    public ResponseEntity<List<QueriesMapping>> getAllQueriesForUser(@PathVariable Long userId) {
	        try {
	            List<QueriesMapping> queriesMappings = queriesMappingServiceImpl.getAllQueriesForUser(userId);
	            return ResponseEntity.ok(queriesMappings);
	        } catch (EntityNotFoundException e) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	        }
	    }
	
	 @PostMapping("/executequery/{userId}")
	    public ResponseEntity<String> executeAssignedQuery(@PathVariable Long userId, @RequestParam Long queryId) {
	        try {
	            String result = queriesMappingServiceImpl.executeAssignedQuery(userId, queryId);
	            return ResponseEntity.ok(result);
	        } catch (EntityNotFoundException e) {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with ID: " + userId);
	        } catch (IllegalArgumentException e) {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid query ID.");
	        } catch (QueryNotAssignedException e) {
	            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("The query is not assigned to the user.");
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred while executing the query.");
	        }
	    }
	
}
