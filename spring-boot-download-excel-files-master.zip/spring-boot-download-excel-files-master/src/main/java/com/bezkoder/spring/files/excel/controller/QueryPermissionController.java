package com.bezkoder.spring.files.excel.controller;

import java.util.Map;
import java.util.Set;

import javax.persistence.EntityNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bezkoder.spring.files.excel.model.QueriesMapping;
import com.bezkoder.spring.files.excel.service.QueriesMappingServiceImpl;

@RestController
@RequestMapping("/api/admin")
public class QueryPermissionController {

	@Autowired
	private QueriesMappingServiceImpl queriesMappingServiceImpl;

//	@PostMapping("/assign-queries/{userId}")
//	public ResponseEntity<String> assignQueriesToUser(@PathVariable Long userId, @RequestBody Set<Long> queryIds) {
//		try {
//		//	QueriesMapping queryMapping = 
//			queriesMappingServiceImpl.assignQueriesToUser(userId, queryIds);
//			return ResponseEntity.ok("Queries assigned successfully.");
//		} catch (EntityNotFoundException e) {
//			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with ID: " + userId);
//		} catch (IllegalArgumentException e) {
//			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid queries provided.");
//		} catch (Exception e) {
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
//					.body("An error occurred while processing the request.");
//		}
//	}
	
	@PostMapping("/assign-queries/{userId}")
	public ResponseEntity<String> assignQueriesToUser(@PathVariable Long userId,  @RequestBody Map<String, Set<Long>> requestData) {
	    try {
	    	Set<Long> queryIds = requestData.get("queryIds");
	        queriesMappingServiceImpl.assignQueriesToUser(userId, queryIds);
	        return ResponseEntity.ok("Queries assigned successfully.");
	    } catch (EntityNotFoundException e) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found with ID: " + userId);
	    } catch (IllegalArgumentException e) {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid queries provided.");
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                .body("An error occurred while processing the request.");
	    }
	}

	
}
