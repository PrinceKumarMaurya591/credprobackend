package com.bezkoder.spring.files.excel.service;

import java.io.ByteArrayInputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bezkoder.spring.files.excel.helper.ExcelHelper;
import com.bezkoder.spring.files.excel.model.Url;
import com.bezkoder.spring.files.excel.repository.TutorialRepository;

@Service
public class ExcelService {
//  @Autowired
//  TutorialRepository repository;
//
//  public ByteArrayInputStream load() {
//    List<Url> tutorials = repository.findAll();
//
//    ByteArrayInputStream in = ExcelHelper.tutorialsToExcel(tutorials);
//    return in;
//  }
	
	
	
//	 @Autowired
//	  TutorialRepository repository;
//
//	  public ByteArrayInputStream loadAll() {
//	    List<Url> urls = repository.findAll();
//	    return createExcel(urls);
//	  }
//
//	  public ByteArrayInputStream loadByCustomQuery(/* Add parameters if necessary */) {
//	    // Implement your custom query logic here
//	    List<Url> urls = repository.yourCustomQueryMethod(/* Pass parameters if necessary */);
//	    return createExcel(urls);
//	  }
//
//	  private ByteArrayInputStream createExcel(List<Url> urls) {
//	    return ExcelHelper.urlsToExcel(urls);
//	  }
	
//	@Autowired
//	  TutorialRepository repository;
//
//	  public ByteArrayInputStream loadAll() {
//	    List<Url> urls = repository.findAll();
//	    return createExcel(urls);
//	  }
//
//	  public ByteArrayInputStream loadByCustomQuery(LocalDateTime startDate, LocalDateTime endDate) {
//	    List<Url> urls = repository.findByCreationDateBetween(startDate, endDate);
//	    return createExcel(urls);
//	  }
//
//	  private ByteArrayInputStream createExcel(List<Url> urls) {
//	    return ExcelHelper.urlsToExcel(urls);
//	  }

	
	
	  @Autowired
	  TutorialRepository repository;

	  public ByteArrayInputStream loadAll() {
	    List<Url> urls = repository.findAll();
	    return createExcel(urls);
	  }

	  public ByteArrayInputStream loadByCustomQuery(String startDateStr, String endDateStr) {
	    // Parse the date strings into LocalDateTime objects
	    LocalDateTime startDate = LocalDateTime.parse(startDateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS"));
	    LocalDateTime endDate = LocalDateTime.parse(endDateStr, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSS"));
	    
	    List<Url> urls = repository.findByCreationDateBetween(startDate, endDate);
	    return createExcel(urls);
	  }

	  private ByteArrayInputStream createExcel(List<Url> urls) {
	    return ExcelHelper.urlsToExcel(urls);
	  }
	}
	


