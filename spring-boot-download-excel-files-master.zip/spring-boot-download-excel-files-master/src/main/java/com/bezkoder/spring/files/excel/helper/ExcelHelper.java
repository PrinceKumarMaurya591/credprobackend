package com.bezkoder.spring.files.excel.helper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.bezkoder.spring.files.excel.model.Url;

public class ExcelHelper {
//  public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
//  static String[] HEADERs = { "Id", "Title", "Description", "Published" };
//  static String SHEET = "Urls";
//
//  public static ByteArrayInputStream tutorialsToExcel(List<Url> tutorials) {
//
//    try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
//      Sheet sheet = workbook.createSheet(SHEET);
//
//      // Header
//      Row headerRow = sheet.createRow(0);
//
//      for (int col = 0; col < HEADERs.length; col++) {
//        Cell cell = headerRow.createCell(col);
//        cell.setCellValue(HEADERs[col]);
//      }
//
//      int rowIdx = 1;
//      for (Url tutorial : tutorials) {
//        Row row = sheet.createRow(rowIdx++);
//
//        row.createCell(0).setCellValue(tutorial.getId());
//        row.createCell(1).setCellValue(tutorial.getEmail());
//        row.createCell(2).setCellValue(tutorial.getOriginalUrl());
//        row.createCell(3).setCellValue(tutorial.getShortLink());
//      }
//
//      workbook.write(out);
//      return new ByteArrayInputStream(out.toByteArray());
//    } catch (IOException e) {
//      throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
//    }
//  }
	
	
	 public static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	  static String[] HEADERS = { "Id", "Original URL", "Short Link", "Creation Date", "Expiration Date", "Client IP Address", "Email" };
	  static String SHEET = "Urls";

	  public static ByteArrayInputStream urlsToExcel(List<Url> urls) {
	    try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream out = new ByteArrayOutputStream();) {
	      Sheet sheet = workbook.createSheet(SHEET);

	      // Header
	      Row headerRow = sheet.createRow(0);
	      for (int col = 0; col < HEADERS.length; col++) {
	        Cell cell = headerRow.createCell(col);
	        cell.setCellValue(HEADERS[col]);
	      }

	      int rowIdx = 1;
	      for (Url url : urls) {
	        Row row = sheet.createRow(rowIdx++);

	        row.createCell(0).setCellValue(url.getId());
	        row.createCell(1).setCellValue(url.getOriginalUrl());
	        row.createCell(2).setCellValue(url.getShortLink());
	        row.createCell(3).setCellValue(url.getCreationDate().toString());
	        row.createCell(4).setCellValue(url.getExpirationDate().toString());
	        row.createCell(5).setCellValue(url.getClientIpAddress());
	        row.createCell(6).setCellValue(url.getEmail());
	      }

	      workbook.write(out);
	      return new ByteArrayInputStream(out.toByteArray());
	    } catch (IOException e) {
	      throw new RuntimeException("Failed to import data to Excel file: " + e.getMessage());
	    }
	  }
	

}
