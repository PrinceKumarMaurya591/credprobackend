package com.bezkoder.spring.files.excel.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bezkoder.spring.files.excel.model.RegistrationRequest;
import com.bezkoder.spring.files.excel.model.User;
import com.bezkoder.spring.files.excel.repository.UserRepository;
import com.bezkoder.spring.files.excel.service.ArloseServiceImpl;

import lombok.extern.slf4j.Slf4j;

import org.springframework.http.ResponseEntity;

@CrossOrigin(origins = "*") 
@RestController 
@Slf4j
@RequestMapping("/credpro") 
public class LoginController { 
	@Autowired 
	ArloseServiceImpl arloseServiceImpl;
	
	@Autowired
	UserRepository userRepository;
	
	// Login Page
	@PostMapping(value = "/validUser")//, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE 
	public ResponseEntity<String> login(@Valid @RequestBody RegistrationRequest registrationRequest) throws Exception {
		//log.info("Inside LoginHomepageController.validUser:Employee code:{}", registrationRequest.getUserName()); 
		String arloseResponse=arloseServiceImpl.getArloseResponse(registrationRequest);
	    

		boolean isValidUser = Boolean.parseBoolean(arloseResponse);
	

        if (isValidUser) {
        	String username = registrationRequest.getUserName(); // Extract the username from the request
            User user = userRepository.findByUsername(username);

            if (user != null) {
                if (user.getRole().equals("ADMIN")) {
                    return ResponseEntity.ok("admin_dashboard_redirect_url");
                } else if (user.getRole().equals("USER")) {
                    return ResponseEntity.ok("USER_dashboard_redirect_url");
                } 
                else {
                    return ResponseEntity.ok("Kindly connect to admin");
                }
            } else {
                return ResponseEntity.badRequest().body("User not found");
            }
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }
}