package com.bezkoder.spring.files.excel.model;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Set;

@Entity
public class QueriesMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Many-to-one relationship with User entity
    @ManyToOne
    private User user;

    // Many-to-many relationship with QueryList entity
    @ManyToMany(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
            name = "user_queries_mapping",
            joinColumns = @JoinColumn(name = "query_mapping_id"),
            inverseJoinColumns = @JoinColumn(name = "query_id")
    )
    private Set<QueryList> allowedQueries;

    
    @ElementCollection
    private Set<Long> queryIds; // This field will store the queryIds
    
    public Set<Long> getQueryIds() {
		return queryIds;
	}

	public void setQueryIds(Set<Long> queryIds) {
		this.queryIds = queryIds;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Set<QueryList> getAllowedQueries() {
        return allowedQueries;
    }

    public void setAllowedQueries(Set<QueryList> allowedQueries) {
        this.allowedQueries = allowedQueries;
    }
}
