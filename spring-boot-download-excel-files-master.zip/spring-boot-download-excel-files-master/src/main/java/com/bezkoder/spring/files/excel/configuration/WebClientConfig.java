package com.bezkoder.spring.files.excel.configuration;
import com.fasterxml.jackson.databind.ObjectMapper; 
import io.netty.handler.ssl.SslContext; 
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;

import javax.net.ssl.SSLException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector; 
import org.springframework.http.codec.json.Jackson2JsonDecoder; 
import org.springframework.http.codec.json.Jackson2JsonEncoder; 
import org.springframework.web.reactive.function.client.WebClient;

import reactor.netty.http.client.HttpClient; 


@Configuration
public class WebClientConfig {

	@Bean
	WebClient webclient() throws SSLException { 
		SslContext sslContext = SslContextBuilder 
				.forClient() 
				.trustManager(InsecureTrustManagerFactory.INSTANCE) 
				.build(); 
		HttpClient httpClient = HttpClient.create() 
				.secure(t -> t.sslContext(sslContext));
		return WebClient.builder() 
				.clientConnector(new ReactorClientHttpConnector(httpClient))
				.codecs(configurer -> { 
					configurer.defaultCodecs().jackson2JsonEncoder(new Jackson2JsonEncoder(new ObjectMapper(), MediaType.APPLICATION_JSON)); 
					configurer.defaultCodecs().jackson2JsonDecoder(new Jackson2JsonDecoder(new ObjectMapper(), MediaType.APPLICATION_JSON)); 
					})
				 .build();
		}
	
	
//	 @Bean
//	    public WebClient webClient() {
//	        return WebClient.builder().build();
//	    }
	
}