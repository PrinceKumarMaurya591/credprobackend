package com.bezkoder.spring.files.excel.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bezkoder.spring.files.excel.model.Url;


@Repository
public interface TutorialRepository extends JpaRepository<Url, Long> {
	
	@Query("SELECT u FROM Url u WHERE u.creationDate BETWEEN :startDate AND :endDate")
	  List<Url> findByCreationDateBetween(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);

	
}
