package com.bezkoder.spring.files.excel.service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bezkoder.spring.files.excel.exception.QueryNotAssignedException;
import com.bezkoder.spring.files.excel.model.QueriesMapping;
import com.bezkoder.spring.files.excel.model.QueryList;
import com.bezkoder.spring.files.excel.model.User;
import com.bezkoder.spring.files.excel.repository.QueriesMappingRepository;
import com.bezkoder.spring.files.excel.repository.QueryListRepository;
import com.bezkoder.spring.files.excel.repository.UserRepository;

//public class QueriesMappingServiceImpl {
//
//}
@Service
public class QueriesMappingServiceImpl {

   
    @Autowired
    private QueriesMappingRepository queriesMappingRepository;
    @Autowired
    private QueryListRepository queryListRepository;
    
    
    
    @Autowired
    private UserRepository userRepository;
   

//    public QueriesMapping assignQueriesToUser(Long userId, Set<Long> queryIds) {
//        User user = userRepository.findById(userId)
//                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));
//		
//
//        Set<QueryList> queries = queryListRepository.findAllByIdIn(queryIds).stream()
//                .collect(Collectors.toSet());;
//        if (queries.isEmpty()) {
//            throw new IllegalArgumentException("No valid queries provided.");
//        }
//
//        QueriesMapping queryMapping = new QueriesMapping();
//        queryMapping.setUser(user);
//        queryMapping.setAllowedQueries(queries);
//
//        return queriesMappingRepository.save(queryMapping);
//        
//    }
    
    
    
//    @Transactional
//    public void assignQueriesToUser(Long userId, Set<Long> queryIds) {
//        User user = userRepository.findById(userId)
//                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));
//
//        Set<QueryList> queries = queryListRepository.findAllByIdIn(queryIds);
//        if (queries.isEmpty()) {
//            throw new IllegalArgumentException("No valid queries provided.");
//        }
//
//        QueriesMapping queriesMapping = new QueriesMapping();
//        queriesMapping.setUser(user);
//        queriesMapping.setAllowedQueries(queries);
//
//        queriesMappingRepository.save(queriesMapping);
//    }
    
    
    
    
    @Transactional
    public void assignQueriesToUser(Long userId, Set<Long> queryIds) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));

        Set<QueryList> queries = queryListRepository.findAllByIdIn(queryIds);
        if (queries.isEmpty()) {
            throw new IllegalArgumentException("No valid queries provided.");
        }

        QueriesMapping queryMapping = new QueriesMapping();
        queryMapping.setUser(user);
        queryMapping.setAllowedQueries(queries);
        queriesMappingRepository.save(queryMapping);

        // Save the queryIds directly in the QueriesMapping entity
        queryMapping.setQueryIds(queryIds);
        queriesMappingRepository.save(queryMapping);
    }
    
    
    public List<QueriesMapping> getAllQueriesForUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));

        return queriesMappingRepository.findByUser(user);
    }

    
    
    public String executeAssignedQuery(Long userId, Long queryId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found with ID: " + userId));

        QueriesMapping queryMapping = user.getRole();
        if (queryMapping == null) {
            throw new QueryNotAssignedException("No queries assigned to the user.");
        }

        Set<QueryList> allowedQueries = queryMapping.getAllowedQueries();
        if (allowedQueries.stream().noneMatch(query -> query.getQueryId().equals(queryId))) {
            throw new IllegalArgumentException("The query is not assigned to the user.");
        }

        // Logic to execute the query and obtain the result (example: using JDBC or JPA to execute the query)

        // Replace the following line with actual query execution logic
        String result = "Query " + queryId + " executed successfully!"; 

        return result;
    }

    
    
}
