package com.bezkoder.spring.files.excel.service;

import com.bezkoder.spring.files.excel.exception.CustomerNotFoundException;
import com.bezkoder.spring.files.excel.model.RegistrationRequest;

public interface ArloseService {

	public String getArloseResponse(RegistrationRequest registrationRequest) throws CustomerNotFoundException;
	
	
	
}
