package com.bezkoder.spring.files.excel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bezkoder.spring.files.excel.configuration.GenricWebClient;
import com.bezkoder.spring.files.excel.exception.CustomerNotFoundException;
import com.bezkoder.spring.files.excel.model.RegistrationRequest;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class ArloseServiceImpl implements ArloseService{

	@Autowired
	GenricWebClient genricWebClient;
	
//	@Value("${arlose.url}")
//	private String arloseUrl; 
	
//	@Override
//	public String getArloseResponse(RegistrationRequest registrationRequest) throws CustomerNotFoundException {
//		String arloseResponse=genricWebClient.post(arloseUrl,registrationRequest, String.class);
//		if(arloseResponse==null) {
//			throw new CustomerNotFoundException("Response Not Found From ARLOSE");
//		}
//		return arloseResponse;
//	}
	
	public String getArloseResponse(RegistrationRequest registrationRequest) {
		String username = registrationRequest.getUserName();
        String password = registrationRequest.getPassword();

        // For testing purposes, let's assume valid credentials for the username "prince" and password "prince"
        if ("prince".equals(username) && "prince".equals(password)) {
            return "true"; // Valid credentials
        } else {
            return "false"; // Invalid credentials
        }
    }

	

}
