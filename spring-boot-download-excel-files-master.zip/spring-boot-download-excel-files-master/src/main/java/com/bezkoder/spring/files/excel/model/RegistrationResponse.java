package com.bezkoder.spring.files.excel.model;

public class RegistrationResponse {

	public RegistrationResponse(String string) {
		
	}

}
