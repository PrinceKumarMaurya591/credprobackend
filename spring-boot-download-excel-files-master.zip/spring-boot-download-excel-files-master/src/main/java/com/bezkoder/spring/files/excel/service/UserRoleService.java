package com.bezkoder.spring.files.excel.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bezkoder.spring.files.excel.model.QueryList;
import com.bezkoder.spring.files.excel.model.QueriesMapping;
import com.bezkoder.spring.files.excel.model.QueriesMapping;
import com.bezkoder.spring.files.excel.repository.QueryListRepository;


//public class UserRoleService {
//
//}

@Service
public class UserRoleService {
//    @Autowired
//    private UserRoleRepository userRoleRepository;
//
//    public Set<String> getAllowedQueriesForUser(String username) {
//        // Assuming you have a method to fetch the UserRole entity by the username
//        // Here, we'll use a dummy method for illustration purposes
//        QueriesMapping userRole = getUserRoleByUsername(username);
//
//        if (userRole != null) {
//            Set<QueryList> allowedQueries = userRole.getAllowedQueries();
//            return allowedQueries.stream().map(QueryList::getQuery).collect(Collectors.toSet());
//        }
//
//        return Collections.emptySet();
//    }
//
//    public boolean isQueryAllowedForUser(String username, String query) {
//        // Assuming you have a method to fetch the UserRole entity by the username
//        // Here, we'll use a dummy method for illustration purposes
//        QueriesMapping userRole = getUserRoleByUsername(username);
//
//        if (userRole != null) {
//            Set<QueryList> allowedQueries = userRole.getAllowedQueries();
//            return allowedQueries.stream().anyMatch(allowedQuery -> allowedQuery.getQuery().equals(query));
//        }
//
//        return false;
//    }
//
//    // Dummy method to get UserRole by username
////    private UserRole getUserRoleByUsername(String username) {
////        // Implement your logic to fetch the UserRole entity by username from the repository
////        // For illustration purposes, we'll assume a hardcoded mapping of usernames to roles
////        if ("user1".equalsIgnoreCase(username)) {
////            UserRole userRole1 = new UserRole();
////            userRole1.setName("User 1");
////            userRole1.setAllowedQueries(new HashSet<>(Arrays.asList(query1, query3)));
////            return userRole1;
////        } else if ("user2".equalsIgnoreCase(username)) {
////            UserRole userRole2 = new UserRole();
////            userRole2.setName("User 2");
////            userRole2.setAllowedQueries(new HashSet<>(Arrays.asList(query7, query4)));
////            return userRole2;
////        } else if ("user3".equalsIgnoreCase(username)) {
////            UserRole userRole3 = new UserRole();
////            userRole3.setName("User 3");
////            userRole3.setAllowedQueries(new HashSet<>(Arrays.asList(query3, query9)));
////            return userRole3;
////        }
////
////        return null;
////    }
//    
//    
//    
//    
//
//
// 
//
//    private QueriesMapping getUserRoleByUsername(String username) {
//        // Fetch the QueryList objects based on their query IDs
//        List<QueryList> query1 = (List<QueryList>) queryListRepository.findByQueryId((long) 1);
//        List<QueryList> query3 = (List<QueryList>)queryListRepository.findByQueryId((long) 3);
//        List<QueryList> query4 = (List<QueryList>) queryListRepository.findByQueryId((long) 4);
//        List<QueryList> query7 = (List<QueryList>) queryListRepository.findByQueryId((long) 7);
//        List<QueryList> query9 = (List<QueryList>) queryListRepository.findByQueryId((long) 9);
//
//        if ("user1".equalsIgnoreCase(username)) {
//            QueriesMapping userRole1 = new QueriesMapping();
//            userRole1.setName("User 1");
//            userRole1.setAllowedQueries(new HashSet<>(Arrays.asList(new UserRoleQueryMapping(query1), new UserRoleQueryMapping(query3))));
//            return userRole1;
//        } else if ("user2".equalsIgnoreCase(username)) {
//            QueriesMapping userRole2 = new QueriesMapping();
//            userRole2.setName("User 2");
//            userRole2.setAllowedQueries(new HashSet<>(Arrays.asList(new UserRoleQueryMapping(query7), new UserRoleQueryMapping(query4))));
//            return userRole2;
//        } else if ("user3".equalsIgnoreCase(username)) {
//            QueriesMapping userRole3 = new QueriesMapping();
//            userRole3.setName("User 3");
//            userRole3.setAllowedQueries(new HashSet<>(Arrays.asList(new UserRoleQueryMapping(query3), new UserRoleQueryMapping(query9))));
//            return userRole3;
//        }
//
//        return null;
//    }
//
//    
//    
//    
//    
//    
//
//    @Autowired
//    private QueryListRepository queryListRepository;
//
//    public void createDummyUserRolesWithQueryMappings() {
//        // Create UserRoles
//        QueriesMapping userRole1 = new QueriesMapping();
//        userRole1.setName("User 1");
//
//        QueriesMapping userRole2 = new QueriesMapping();
//        userRole2.setName("User 2");
//
//        QueriesMapping userRole3 = new QueriesMapping();
//        userRole3.setName("User 3");
//
//        // Fetch the QueryList objects based on their query IDs
//        QueryList query1 = queryListRepository.findById(1L).orElse(null);
//        QueryList query3 = queryListRepository.findById(3L).orElse(null);
//        QueryList query4 = queryListRepository.findById(4L).orElse(null);
//        QueryList query7 = queryListRepository.findById(7L).orElse(null);
//        QueryList query9 = queryListRepository.findById(9L).orElse(null);
//
//        // Associate queries with the appropriate UserRoles
//        userRole1.setAllowedQueries(new HashSet<>(Arrays.asList(query1, query3)));
//        userRole2.setAllowedQueries(new HashSet<>(Arrays.asList(query7, query4)));
//        userRole3.setAllowedQueries(new HashSet<>(Arrays.asList(query3, query9)));
//        userRole3.setAllowedQueries(new HashSet<>(Arrays.asList(query3, query9)));
//        // Save the UserRoles
//        userRoleRepository.saveAll(Arrays.asList(userRole1, userRole2, userRole3));
//    }

    
}
