package com.bezkoder.spring.files.excel.service;


import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bezkoder.spring.files.excel.model.QueryList;
import com.bezkoder.spring.files.excel.model.QueriesMapping;
import com.bezkoder.spring.files.excel.model.QueriesMapping;
import com.bezkoder.spring.files.excel.repository.QueryListRepository;


//@Service
//public class UserRoleQueryMappingService {
//
//    @Autowired
//    private UserRoleQueryMappingRepository queryMappingRepository;
//
//    @Autowired
//    private UserRoleRepository userRoleRepository;
//    
//    @PostConstruct
//    public void initUserRoleQueryMapping() {
//        // Initialize and populate the UserRoleQueryMapping entity with allowedQueries for each UserRole
//
//        // Example: Populate the allowedQueries for "manager" role
//        UserRoleQueryMapping managerQueryMapping = new UserRoleQueryMapping();
//        managerQueryMapping.setUserRole(userRoleRepository.findByName("manager"));
//        managerQueryMapping.setAllowedQueries(new HashSet()<>(Arrays.asList(
//            "SELECT * FROM table_name WHERE name = ?",
//            "SELECT * FROM table_name WHERE date = ?",
//            // Add other allowed queries for the "manager" role here
//        )));
//        queryMappingRepository.save(managerQueryMapping);
//
//        // Example: Populate the allowedQueries for "avp" role
//        UserRoleQueryMapping avpQueryMapping = new UserRoleQueryMapping();
//        avpQueryMapping.setUserRole(userRoleRepository.findByName("avp"));
//        avpQueryMapping.setAllowedQueries(new HashSet<>(Arrays.asList(
//            "SELECT * FROM table_name WHERE name = ?",
//            "SELECT * FROM table_name WHERE date = ?",
//            "UPDATE table_name SET column_name = ? WHERE id = ?",
//            "DELETE FROM table_name WHERE id = ?",
//            // Add other allowed queries for the "avp" role here
//        )));
//        queryMappingRepository.save(avpQueryMapping);
//
//        // Add similar initialization for other roles as needed
//    }
    
    

       

//        public void createDummyUserRoleWithQueryMappings() {
//            UserRole userRole = new UserRole();
//            userRole.setName("ADMIN");
//
//            UserRoleQueryMapping queryMapping1 = new UserRoleQueryMapping();
//            queryMapping1.setAllowedQueries(new HashSet<>(Arrays.asList("SELECT * FROM table1", "SELECT * FROM table2")));
//
//            UserRoleQueryMapping queryMapping2 = new UserRoleQueryMapping();
//            queryMapping2.setAllowedQueries(new HashSet<>(Collections.singletonList("SELECT * FROM table3")));
//
//            userRole.setQueryMappings(new HashSet<>(Arrays.asList(queryMapping1, queryMapping2)));
//
//            userRoleRepository.save(userRole);
//        }
//        
        
        
//        public void setupUsersWithQueryMappings() {
//            // Create and save user1 with query mappings
//            UserRole user1 = new UserRole();
//            user1.setName("USER1");
//
//            UserRoleQueryMapping user1QueryMapping1 = new UserRoleQueryMapping();
//            user1QueryMapping1.setAllowedQueries(new HashSet<>(Arrays.asList("SELECT * FROM table1", "SELECT * FROM table2")));
//
//            UserRoleQueryMapping user1QueryMapping2 = new UserRoleQueryMapping();
//            user1QueryMapping2.setAllowedQueries(new HashSet<>(Collections.singletonList("SELECT * FROM table3")));
//
//            user1.setQueryMappings(new HashSet<>(Arrays.asList(user1QueryMapping1, user1QueryMapping2)));
//
//            userRoleRepository.save(user1);
//
//            // Create and save user2 with query mappings
//            UserRole user2 = new UserRole();
//            user2.setName("USER2");
//
//            UserRoleQueryMapping user2QueryMapping1 = new UserRoleQueryMapping();
//            user2QueryMapping1.setAllowedQueries(new HashSet<>(Collections.singletonList("SELECT * FROM table4")));
//
//            UserRoleQueryMapping user2QueryMapping2 = new UserRoleQueryMapping();
//            user2QueryMapping2.setAllowedQueries(new HashSet<>(Arrays.asList("SELECT * FROM table1", "SELECT * FROM table5")));
//
//            user2.setQueryMappings(new HashSet<>(Arrays.asList(user2QueryMapping1, user2QueryMapping2)));
//
//            userRoleRepository.save(user2);
//        }
//    
        
        
//    @Service
//    public class UserRoleService {
//        @Autowired
//        private UserRoleRepository userRoleRepository;
//
//        @Autowired
//        private QueryListRepository queryListRepository;
//
//        public void createDummyUserRolesWithQueryMappings() {
//            // Create UserRoles
//            UserRole userRole1 = new UserRole();
//            userRole1.setName("User 1");
//
//            UserRole userRole2 = new UserRole();
//            userRole2.setName("User 2");
//
//            UserRole userRole3 = new UserRole();
//            userRole3.setName("User 3");
//
//            // Fetch the QueryList objects based on their query IDs
//            QueryList query1 = queryListRepository.findById(1L).orElse(null);
//            QueryList query3 = queryListRepository.findById(3L).orElse(null);
//            QueryList query4 = queryListRepository.findById(4L).orElse(null);
//            QueryList query7 = queryListRepository.findById(7L).orElse(null);
//            QueryList query9 = queryListRepository.findById(9L).orElse(null);
//
//            // Associate queries with the appropriate UserRoles
//            userRole1.setAllowedQueries(new HashSet<>(Arrays.asList(query1, query3)));
//            userRole2.setAllowedQueries(new HashSet<>(Arrays.asList(query7, query4)));
//            userRole3.setAllowedQueries(new HashSet<>(Arrays.asList(query3, query9)));
//            userRole3.setAllowedQueries(new HashSet<>(Arrays.asList(query3, query9)));
//            // Save the UserRoles
//            userRoleRepository.saveAll(Arrays.asList(userRole1, userRole2, userRole3));
//        }
//
//		public Set<String> getAllowedQueriesForUser(String username) {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//		
//    }

    
  
    
    
        
        
  //  }




    

