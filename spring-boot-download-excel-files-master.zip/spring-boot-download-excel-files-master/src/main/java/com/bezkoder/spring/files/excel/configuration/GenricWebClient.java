package com.bezkoder.spring.files.excel.configuration;

import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;

@Configuration
public class GenricWebClient {

	@Autowired
	WebClient webClient;

	public <T, K> K post(String url, T request, Class<K> clazz) {
		URI uri = UriComponentsBuilder.fromUriString(url).build().toUri();
		K response = webClient.post().uri(uri).header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.body(BodyInserters.fromValue(request)).retrieve().bodyToMono(clazz).block();
		return response;
	}

	public <K> K get(String url, Class<K> clazz) {
		URI uri = UriComponentsBuilder.fromUriString(url).build().toUri();
		K response = webClient.get().uri(uri).header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
				.retrieve().bodyToMono(clazz).block();
		return response;
	}
}