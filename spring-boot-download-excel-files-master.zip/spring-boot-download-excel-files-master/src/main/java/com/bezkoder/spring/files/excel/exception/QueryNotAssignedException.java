package com.bezkoder.spring.files.excel.exception;

public class QueryNotAssignedException extends RuntimeException {

    public QueryNotAssignedException(String message) {
        super(message);
    }
}
