package com.bezkoder.spring.files.excel.repository;

import java.util.Collection;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bezkoder.spring.files.excel.model.QueryList;

@Repository
public interface QueryListRepository extends JpaRepository<QueryList, Long>{

	

//    // Custom query method to find a QueryList by its query name
//    QueryList findByQueryName(String queryName);
//
//    // Custom query method to find QueryLists by their IDs
//    Set<QueryList> findAllById(Set<Long> ids);
	
    @Query("SELECT q FROM QueryList q WHERE q.queryId IN :queryIds")
    Set<QueryList> findAllByIdIn(@Param("queryIds") Set<Long> queryIds);
    
}
