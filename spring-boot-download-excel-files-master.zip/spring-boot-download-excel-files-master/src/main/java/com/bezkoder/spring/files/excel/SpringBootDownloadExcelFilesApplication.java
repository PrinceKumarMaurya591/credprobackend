package com.bezkoder.spring.files.excel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDownloadExcelFilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDownloadExcelFilesApplication.class, args);
	}

}
