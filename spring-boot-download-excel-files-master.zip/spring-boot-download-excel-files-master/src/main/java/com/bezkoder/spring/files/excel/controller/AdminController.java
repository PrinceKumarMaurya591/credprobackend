package com.bezkoder.spring.files.excel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bezkoder.spring.files.excel.model.Admin;

import com.bezkoder.spring.files.excel.model.User;

import com.bezkoder.spring.files.excel.model.QueriesMapping;
import com.bezkoder.spring.files.excel.repository.AdminRepository;


import com.bezkoder.spring.files.excel.repository.UserRepository;


@RestController
public class AdminController {

//    @Autowired
//    private AdminRepository adminRepository;
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Autowired
//    private UserRoleRepository userRoleRepository;
//
//    @Autowired
//    private QueryPermissionRepository queryPermissionRepository;
//
//    @Autowired
//    private UserGroupRepository userGroupRepository;
//
//    @PostMapping("/admins")
//    public ResponseEntity<Admin> createAdmin(@RequestBody Admin admin) {
//        // Perform validation if necessary
//        adminRepository.save(admin);
//        return ResponseEntity.ok(admin);
//    }
//
//    @PostMapping("/admins/{adminId}/users")
//    public ResponseEntity<String> createUser(@PathVariable Long adminId, @RequestBody User user) {
//        Admin admin = adminRepository.findById(adminId).orElse(null);
//        if (admin == null) {
//            return ResponseEntity.notFound().build();
//        }
//
//        // Check if the provided user role ID exists in the database
//        QueriesMapping requestedUserRole = user.getRole();
//        if (requestedUserRole != null) {
//            Long requestedUserRoleId = requestedUserRole.getId();
//            QueriesMapping existingUserRole = null;
//            if (requestedUserRoleId != null) {
//                existingUserRole = userRoleRepository.findById(requestedUserRoleId).orElse(null);
//            }
//
//            // If the role is not found by ID, try to find it by name
//            if (existingUserRole == null && requestedUserRole.getName() != null) {
//                String requestedUserRoleName = requestedUserRole.getName();
//                existingUserRole = userRoleRepository.findByName(requestedUserRoleName);
//            }
//
//            if (existingUserRole == null) {
//                return ResponseEntity.badRequest().body("Requested user role not found in the database");
//            }
//            user.setRole(existingUserRole); // Set the provided user role from the request body
//        } else {
//            // Fetch the default user role (e.g., "USER") from the database
//            QueriesMapping defaultUserRole = userRoleRepository.findByName("USER");
//
//            if (defaultUserRole == null) {
//                return ResponseEntity.badRequest().body("Default user role not found in the database");
//            }
//
//            // If the provided user role is null, set the default user role
//            user.setRole(defaultUserRole);
//        }
//
//        // Perform validation if necessary
//        userRepository.save(user);
//        return ResponseEntity.ok("User created successfully");
//    }
//
//
//
//
//
//    @PostMapping("/admins/{adminId}/roles")
//    public ResponseEntity<QueriesMapping> createRole(@PathVariable Long adminId, @RequestBody QueriesMapping role) {
//        Admin admin = adminRepository.findById(adminId).orElse(null);
//        if (admin == null) {
//            return ResponseEntity.notFound().build();
//        }
//
//        String roleName = role.getName();
//
//        // Check if the role with the same name already exists in the database
//        QueriesMapping existingRole = userRoleRepository.findByName(roleName);
//        if (existingRole != null) {
//            // If the role with the same name exists, return it without saving a new one
//            return ResponseEntity.ok(existingRole);
//        }
//
//        // If the role with the same name does not exist, save the new role
//        userRoleRepository.save(role);
//        return ResponseEntity.ok(role);
//    }
//
//
//    @PostMapping("/admins/{adminId}/groups")
//    public ResponseEntity<UserGroup> createGroup(@PathVariable Long adminId, @RequestBody UserGroup group) {
//        Admin admin = adminRepository.findById(adminId).orElse(null);
//        if (admin == null) {
//            return ResponseEntity.notFound().build();
//        }
//
//        // Perform validation if necessary
//        userGroupRepository.save(group);
//        return ResponseEntity.ok(group);
//    }
//
//    @PostMapping("/admins/{adminId}/permissions")
//    public ResponseEntity<QueryPermission> grantPermission(
//            @PathVariable Long adminId,
//            @RequestParam String username,
//            @RequestParam String query
//    ) {
//        Admin admin = adminRepository.findById(adminId).orElse(null);
//        if (admin == null) {
//            return ResponseEntity.notFound().build();
//        }
//
//        User user = userRepository.findByUsername(username);
//        if (user == null) {
//            return ResponseEntity.notFound().build();
//        }
//
//        QueryPermission permission = new QueryPermission();
//        permission.setAdmin(admin);
//        permission.setUser(user);
//        permission.setQuery(query);
//
//        queryPermissionRepository.save(permission);
//        return ResponseEntity.ok(permission);
//    }
//    
////    private Permission getPermissionForQuery(String query, UserRole userRole) {
////        UserRoleQueryMapping queryMapping = userRole.getQueryMapping();
////        if (queryMapping != null) {
////            Set<String> allowedQueries = queryMapping.getAllowedQueries();
////
////            // Check if the requested query is allowed for the user's role
////            if (allowedQueries.contains(query)) {
////                // Return a Permission object indicating the action is allowed
////                return new Permission(true);
////            }
////        }
////
////        // If the user role does not have the necessary permissions for the query, return null
////        return null;
////    }
    
}
